This folder has 3 files

1. General_project has SPI and nordic drivers along with TX and RX interrupt handlers for all modules

2. DMA_KL25Z_SPI1_SPI0 is an extra work where we try to use dma with spi to control one component as master and other as slave
3. Third is our beaglebone SPI driver